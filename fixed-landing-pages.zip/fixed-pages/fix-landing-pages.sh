#!/bin/bash
# Script to fix landing pages in the GitBook export
# Run from: ~/work/git-book-developer/

echo "🔧 Fixing landing pages..."

# Backup originals
mkdir -p backups
cp README.md backups/ 2>/dev/null
cp homepage.md backups/ 2>/dev/null
cp homepage/iot-industrial-product-line.md backups/ 2>/dev/null
cp homepage/networking-product-line.md backups/ 2>/dev/null
cp homepage/solidsense.md backups/ 2>/dev/null
cp homepage/bedrock-pc.md backups/ 2>/dev/null
cp homepage/other-articles.md backups/ 2>/dev/null

echo "✅ Backed up original files to backups/"

# Copy fixed files
cp fixed-pages/README.md ./README.md
cp fixed-pages/README.md ./homepage.md
cp fixed-pages/iot-industrial-product-line.md homepage/iot-industrial-product-line.md
cp fixed-pages/networking-product-line.md homepage/networking-product-line.md
cp fixed-pages/solidsense.md homepage/solidsense.md
cp fixed-pages/bedrock-pc.md homepage/bedrock-pc.md
cp fixed-pages/other-articles.md homepage/other-articles.md

echo "✅ Replaced landing pages with fixed versions"

# Clean up
rm -rf fixed-pages/

echo ""
echo "🎉 Done! Now run:"
echo "   git add ."
echo "   git commit -m 'Fix landing pages - replace JS with proper markdown'"
echo "   git push"
